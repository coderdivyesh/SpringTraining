package com.shop;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProductConfig {
	
	@Bean(name="product")
	public Product getProduct()
	{
		Product product=new Product();
		product.setName("LG");
		product.setPrice(10000d);
		return product;
	}
	
	@Bean(name="product2")
	public Product getProduct2()
	{
		Product product=new Product();
		product.setName("Sony");
		product.setPrice(20000d);
		return product;
	}

}
