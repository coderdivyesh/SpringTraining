package com.shop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value="cart")
@Scope("prototype")
public class ShoppingCart {

	private List<Product> products = new ArrayList<Product>();
	
	public void add(Product product){
		products.add(product);
	}
	
	public List<Product> getProducts(){
		return products;
	}

}
