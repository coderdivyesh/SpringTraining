package com.shop;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;

public class Cashier implements BeanNameAware,MessageSourceAware{
	private String name;
	private FileWriter writer;
	private String path;
	private MessageSource messageSource;
	public void checkout(ShoppingCart cart)
	{
		double total=0;
		for(Product product: cart.getProducts())
		{
			total+=product.getPrice();
		}
		
		String totalmsg=messageSource.getMessage("msg",null, Locale.US);
		String msg=name + totalmsg +total ;
		try {
			writer.write(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(msg);
	}

	@Override
	public void setBeanName(String name) {
		this.name=name;
		
	}


	public void stop() throws Exception {
		
		writer.close();
	}


	public void start() throws Exception {
		writer=new FileWriter(path + "abc.txt",true);
		
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public void setMessageSource(MessageSource arg0) {
		messageSource=arg0;
		
	}
	
	

}
