package com.shop;

import java.io.File;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class PathCheckingPostProcessor implements BeanPostProcessor {

	
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("inside");
		if(bean instanceof Cashier)
		{
			Cashier cashier=(Cashier)bean;
			
			String path=cashier.getPath();
			File file=new File(path);
			if(!file.exists())
			{
				file.mkdirs();
			}
		}
		return bean;
	}
	
	
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		return bean;
	}

}
