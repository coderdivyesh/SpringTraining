package com.domain;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Student {

	private int[] marks;
	private List<String> names;
	private Set<String> address;
	private Map<String,String> pairs;
	private Properties properties;

	public int[] getMarks() {
		return marks;
	}

	public void setMarks(int[] marks) {
		this.marks = marks;
	}

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	public Set<String> getAddress() {
		return address;
	}

	public void setAddress(Set<String> address) {
		this.address = address;
	}

	public Map<String, String> getPairs() {
		return pairs;
	}

	public void setPairs(Map<String, String> pairs) {
		this.pairs = pairs;
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	@Override
	public String toString() {
		return "Student [marks=" + Arrays.toString(marks) + ", names=" + names + ", address=" + address + ", pairs="
				+ pairs + ", properties=" + properties + "]";
	}
	
	

	
	
	
	
}
