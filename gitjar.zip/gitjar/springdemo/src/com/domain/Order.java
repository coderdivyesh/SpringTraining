package com.domain;

public class Order {

	private Item item;

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Order(Item item) {
		this.item = item;
	}
	
	
	
}
