package com.domain;

import org.springframework.beans.factory.BeanNameAware;

public class Item implements BeanNameAware {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void setBeanName(String arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
}
