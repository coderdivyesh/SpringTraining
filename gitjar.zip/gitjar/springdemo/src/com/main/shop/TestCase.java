package com.main.shop;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shop.Cashier;
import com.shop.Product;
import com.shop.ShoppingCart;

public class TestCase {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext context=new ClassPathXmlApplicationContext("com/shop/mybean-shop.xml");
		Product product=context.getBean("product",Product.class);
		Product product2=context.getBean("product2",Product.class);
		//Product product3=context.getBean("product3",Product.class);
		
		ShoppingCart cart= context.getBean("cart", ShoppingCart.class);
		cart.add(product);
		cart.add(product2);
	
		
		Cashier cashier= context.getBean("jerry", Cashier.class);
		cashier.checkout(cart);
		
		context.registerShutdownHook();
	}

}
