package com.main;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.domain.Employee;
import com.domain.Order;
import com.domain.Student;

public class TestCase {
	
	public static void main(String args[])
	{
		ConfigurableApplicationContext context= new ClassPathXmlApplicationContext("com/domain/mybean.xml");
		Employee employee= context.getBean("e", Employee.class);
		System.out.println(employee);
		
		Employee employee2= context.getBean("e2", Employee.class);
		System.out.println(employee2);
		
		Order order=context.getBean("order",Order.class);
		System.out.println(order.getItem().getName());
		
		Student student=context.getBean("student",Student.class);
		System.out.println(student);
		
		Student student2=context.getBean("student",Student.class);
		System.out.println(student);
		
		System.out.println(student==student2);
		
		context.registerShutdownHook();
		
	}

}
