package com.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {/*
	
	@Pointcut("execution(* *com.dao.*.*(*))")
	public void pointcutArgs(){
		
	}
	
	@Pointcut("execution(* *com.dao.*.get*(..))")
	public void pointcutGet(){
		
	}
	
	@Before("pointcutArgs()") //inside value is the name of point cut which is mandatory
	public void adviceLoggingArguments(JoinPoint joinPoint){
		//try{
			System.out.println("--------Before Advice --------------");
			System.out.println("Method name is : " + joinPoint.getSignature().getName());
			System.out.println("Args are:" + joinPoint.getArgs()[0]);
			System.out.println("------------------------------------");
			//throw new ArithmeticException(); // close Before code inside try-catch to handle this exception
		//}
		catch(Exception e)
		{
			System.out.println("Exception caught in Before");
		}
		
	}
	
	
	// called after method executed is executed despite of whether the exception is raised or not.
	@After("pointcutArgs()")
	public void afterAdvice(JoinPoint joinPoint)
	{
		System.out.println("--------After Advice --------------");
		System.out.println("Method name is : " + joinPoint.getSignature().getName());
		System.out.println("Args are:" + joinPoint.getArgs()[0]);
		System.out.println("------------------------------------");
	}
	
	@AfterReturning(returning="obj",pointcut="pointcutGet()")
	public void afterReturningAdvice(JoinPoint joinPoint, Object obj){

		System.out.println("--------After Returning Advice --------------");
		System.out.println("Method name is : " + joinPoint.getSignature().getName());
		System.out.println("Return value is: "+obj);
		//System.out.println("Args are:" + joinPoint.getArgs()[0]);
		System.out.println("------------------------------------");
	
	}
	
	// Used to hadle the exception that are thrown/raised
	@AfterThrowing(throwing="ex",pointcut="pointcutArgs()")
	public void afterThrowingAdvice(JoinPoint joinPoint, Throwable ex){

		System.out.println("--------After Throwing Advice --------------");
		System.out.println("Method name is : " + joinPoint.getSignature().getName());
		System.out.println("Exception Message is:"+ex.getMessage());
		//System.out.println("Args are:" + joinPoint.getArgs()[0]);
		System.out.println("------------------------------------");
	
	}

*/}
