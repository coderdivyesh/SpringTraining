package com.aspects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class PerformanceMoniteringAspect {
	
	@Pointcut("execution(* *com.dao.IStudentDao.getAll*())") // Give Inteface Name or Impl name..it make no chnage
	public void pointcutgets(){
		
	}
	
	
	// Signatute of Around: public Object aroundAdvice() throws Exception
	@Around("pointcutgets()")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable{
		
		Object result=null;
		try {
			System.out.println("Before Advice");
			long starttime=System.currentTimeMillis();
			result=joinPoint.proceed();// if you not write this line business logic will not be called. This line route the call to business logic
			long endtime=System.currentTimeMillis();
			System.out.println("Time taken is: "+ (int)(endtime-starttime));
			System.out.println("After Returning Advice");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			System.out.println("After throwing Advice" + e.getMessage());
			throw e;
		} 
		return result;
		
	}

}
