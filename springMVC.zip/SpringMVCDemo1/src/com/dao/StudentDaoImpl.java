package com.dao;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.domain.Student;

@Repository
public class StudentDaoImpl implements IStudentDao{

	@Autowired
	private HibernateTemplate template;
	
	@Override
	@Transactional
	public void insert(Student student) {
		template.save(student);
		System.out.println("record inserted successfully");
		//throw new NullPointerException("record not inserted"); // if no Tx Manager is used, record will be saved in DB
		//throw new ArithmeticException("Arithmetic Exception Raised");
		
	}

	@Override
	@Transactional // Add Tx from NameSpace for this and update xml. At back end it will use org.springframework.orm.hibernate3.TransactionAwareDataSourceConnectionProvider
	public void update(Student student) {
		
		template.update(student);
		System.out.println("record updated successfully");
		try {
			throw new IOException("record not updated");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("record updated successfully");
		}
		
	}

	@Override
	@Transactional
	public void delete(Integer rollno) {
		
		Student student=template.get(Student.class, rollno);
		template.delete(student);
		System.out.println("record deleted successfully");
		
	}

	@Override
	@Transactional(readOnly=true)
	public Student getStudentByRollno(Integer rollno) {
		System.out.println("getStudentByRollno method");
		return template.get(Student.class, rollno);
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<Student> getAllStudents() {
		System.out.println("getAllStudents method");
		
		return template.find("from com.domain.Student");
	}

}
