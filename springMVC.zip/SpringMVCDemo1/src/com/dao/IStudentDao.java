package com.dao;

import java.util.List;

import com.domain.Student;

public interface IStudentDao {
	
	void insert(Student student);
	void update(Student student);
	void delete(Integer rollno); // Hibernate says to make it a Wrapper class
	Student getStudentByRollno(Integer rollno);
	List<Student> getAllStudents();
	

}
