package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.domain.Student;
import com.service.IStudentService;

@Controller("studentMvcController")
@Scope("request")
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private IStudentService studentService;
	
	//@RequestMapping(value={"print","getAllStudents"})
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getAllStudents() {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("students", studentService.getAllStudents());
		modelAndView.setViewName("showstudents");
		return modelAndView;
		
	}
	
	@RequestMapping(value="register",method= RequestMethod.GET)
	public ModelAndView gotoRegistrationPage()
	{
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("stud", new Student());
		modelAndView.setViewName("registration");
		return modelAndView;
	}
	
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String insertStudent(@ModelAttribute("stud") Student student)
	{
		studentService.insert(student);
		return"success";
	}
}
