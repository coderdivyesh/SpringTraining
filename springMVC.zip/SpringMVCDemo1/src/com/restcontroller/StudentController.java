package com.restcontroller;

import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.domain.Student;
import com.service.IStudentService;

@Controller("studentRestController")
@Scope("request")
@RequestMapping("/students")
public class StudentController {
	
	private IStudentService studentService;
	
	@ResponseStatus(value= HttpStatus.CREATED)
	@RequestMapping(value="/insert", method=RequestMethod.POST,consumes={"application/xml","application/json"})
	public void insertStudent(@RequestBody Student student) {
		studentService.insert(student);
	}
	
	@ResponseStatus(value= HttpStatus.OK)
	@RequestMapping(value="/update", method=RequestMethod.PUT,consumes={"application/xml","application/json"})
	public void updateStudent(@RequestBody Student student) {
		studentService.update(student);
	}
	@ResponseStatus(value= HttpStatus.OK)
	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE,consumes={"application/xml","application/json"})
	public void deleteStudent(@PathVariable("id") Integer rollno) {
		studentService.delete(rollno);
	}
	
	
	@ResponseStatus(value= HttpStatus.OK)
	@RequestMapping(value="/{id}", method=RequestMethod.GET,produces={"application/xml","application/json"})
	@ResponseBody
	public Student getStudentByRollno(@PathVariable("id") Integer rollno) {
		
		return studentService.getStudentByRollno(rollno);
	}

}
