package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dao.IStudentDao;
import com.domain.Student;

@Service
public class StudentServiceImpl implements IStudentService{
	
	@Autowired
	// @Qualifier("studentDaoImpl") support multiple implementations
	private IStudentDao studentDao;

	@Override
	public void insert(Student student) {
		System.out.println("Inside Insert");
		studentDao.insert(student);
		
	}

	@Override
	public void update(Student student) {
		studentDao.update(student);
		
	}

	@Override
	public void delete(Integer rollno) {
		studentDao.delete(rollno);
		
	}

	@Override
	public Student getStudentByRollno(Integer rollno) {
		return studentDao.getStudentByRollno(rollno);
		}

	@Override
	public List<Student> getAllStudents() {
		return studentDao.getAllStudents();
		
	}

}
