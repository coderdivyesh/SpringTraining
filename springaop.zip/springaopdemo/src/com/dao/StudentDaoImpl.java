package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.domain.Student;

@Repository
public class StudentDaoImpl implements IStudentDao{

	@Autowired
	private HibernateTemplate template;
	
	@Override
	public void insert(Student student) {
		template.save(student);
		System.out.println("record inserted successfully");
		//throw new ArithmeticException("Arithmetic Exception Raised");
		
	}

	@Override
	public void update(Student student) {
		
		template.update(student);
		System.out.println("record updated successfully");
		
	}

	@Override
	public void delete(Integer rollno) {
		
		Student student=template.get(Student.class, rollno);
		template.delete(student);
		System.out.println("record deleted successfully");
		
	}

	@Override
	public Student getStudentByRollno(Integer rollno) {
		System.out.println("getStudentByRollno method");
		return template.get(Student.class, rollno);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Student> getAllStudents() {
		System.out.println("getAllStudents method");
		
		return template.find("from com.domain.Student");
	}

}
