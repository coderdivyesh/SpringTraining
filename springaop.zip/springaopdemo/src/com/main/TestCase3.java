package com.main;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.domain.Student;
import com.service.IStudentService;

public class TestCase3 {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("mybean.xml");

		IStudentService service = context.getBean("studentServiceImpl", IStudentService.class);
		//Above line is equivalent to below line
		//IStudentService service1=new StudentServiceImpl();
		
		System.out.println(service.getAllStudents());
		System.out.println(service.getStudentByRollno(1));
		service.delete(1);
		context.registerShutdownHook();

	}

}
