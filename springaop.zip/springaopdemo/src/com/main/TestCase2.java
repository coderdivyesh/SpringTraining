package com.main;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.domain.Student;
import com.service.IStudentService;

public class TestCase2 {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("mybean.xml");

		IStudentService service = context.getBean("studentServiceImpl", IStudentService.class);
		//Above line is equivalent to below line
		//IStudentService service1=new StudentServiceImpl();
		
		Student student = new Student();
		student.setName("divyesh");
		student.setRollno(1);
		student.setPercentage(91.50d);
		service.update(student);
		/*service.getAllStudents();
		service.getStudentByRollno(1);*/
		context.registerShutdownHook();

	}

}
