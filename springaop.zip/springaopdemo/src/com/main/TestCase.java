package com.main;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.domain.Student;
import com.service.IStudentService;

public class TestCase {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("mybean.xml");

		IStudentService service = context.getBean("studentServiceImpl", IStudentService.class);
		//Above line is equivalent to below line
		//IStudentService service1=new StudentServiceImpl();
		
		Student student = new Student();
		student.setName("Jerry");
		student.setRollno(1);
		student.setPercentage(99.9d);
		service.insert(student);
		service.getAllStudents();
		service.getStudentByRollno(1);
		context.registerShutdownHook();

	}

}
